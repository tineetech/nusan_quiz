﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

init python:
    hasil = { "benar_jawaban": 0, "terjawab": 0 }


label main_menu:
    return

# The game starts here.
label start:

label intro:
    $ renpy.movie_cutscene("video/opening_video.mp4")

label scene_1:
    scene bg_keraton_yogyakarta with fade
    show ch_diponegoro at center
    "Diponegoro" "Mereka membangun jalan melewati makam leluhurku. Ini adalah penghinaan terhadap adat dan martabat kami."

    show ch_patih at left
    "Patih Kraton" "Kanjeng Pangeran, Belanda mengklaim ini demi pembangunan. Tapi rakyat resah. Tanah mereka dirampas tanpa belas kasihan."

    show ch_utusan_belanda at right
    "Utusan Belanda" "Tanah ini milik pemerintah kolonial. Siapa pun yang menghalangi akan dianggap melawan hukum."
    "Diponegoro" "Kalau begitu, biarlah rakyat yang menentukan. Kami tidak akan tunduk pada ketidakadilan!"

menu question_1:
    "Apa penyebab utama Perang Diponegoro meletus?"

    "A. Penurunan jabatan Pangeran Diponegoro":
        $ hasil["terjawab"] += 1
    "B. Pembangunan jalan oleh Belanda yang melewati makam leluhur":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "C. Konflik antara Yogyakarta dan Surakarta":
        $ hasil["terjawab"] += 1
    "D. Pajak perdagangan hasil bumi":
        $ hasil["terjawab"] += 1

menu question_2:
    "Siapa tokoh yang memimpin perlawanan terhadap Belanda dalam perang ini?"

    "A. Sultan Agung":
        $ hasil["terjawab"] += 1
    "B. Jenderal Sudirman":
        $ hasil["terjawab"] += 1
    "C. Pangeran Diponegoro":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "D. Raden Inten":
        $ hasil["terjawab"] += 1

label scene_2:
    scene bg_desa_terbakar with fade
    show ch_diponegoro at left
    "Diponegoro" "Kita tidak bisa diam. Perlawanan ini suci. Untuk agama, tanah air, dan kehormatan."

    show ch_kyai_mojo at right
    "Kyai Mojo" "Perjuangan ini adalah jihad. Kita lawan dengan kekuatan dan keyakinan."

    show ch_sentot at center
    "Sentot" "Pasukan sudah siap, Pangeran. Rakyat bergabung dari seluruh penjuru."
    "Diponegoro" "Kalau begitu, biarkan sejarah mencatat: inilah awal dari perang kemerdekaan kami!"

menu question_3:
    "Siapakah ulama yang mendukung Pangeran Diponegoro dalam perjuangannya?"

    "A. Kyai Haji Ahmad Dahlan":
        $ hasil["terjawab"] += 1
    "B. Kyai Mojo":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "C. KH Hasyim Asy'ari":
        $ hasil["terjawab"] += 1
    "D. Kyai Wahid Hasyim":
        $ hasil["terjawab"] += 1

menu question_4:
    "Apa alasan utama Pangeran Diponegoro memulai perlawanan terhadap Belanda?"

    "A. Persaingan dagang":
        $ hasil["terjawab"] += 1
    "B. Kekuasaan politik":
        $ hasil["terjawab"] += 1
    "C. Perjuangan atas nama agama dan keadilan":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "D. Konflik dengan keraton":
        $ hasil["terjawab"] += 1

label scene_3:
    scene bg_hutan_pertempuran with fade
    show ch_diponegoro at left
    "Diponegoro" "Serang dari hutan dan gunung. Jangan hadapi mereka di medan terbuka!"

    show ch_sentot at right
    "Sentot" "Pasukan kita menguasai medan. Belanda tidak mengenal hutan ini."

    show ch_jenderal_belanda at center
    "Jenderal Belanda" "Kami mengalami kerugian besar. Mereka tak terlihat tapi menyerang dari segala arah!"

    voice "Scene3_Narator.mp3"
    "Narator" "Perang berlangsung dengan sengit. Taktik gerilya Diponegoro membuat Belanda kewalahan."

menu question_5:
    "Apa taktik utama yang digunakan Pangeran Diponegoro dalam perang?"

    "A. Perang laut":
        $ hasil["terjawab"] += 1
    "B. Serangan udara":
        $ hasil["terjawab"] += 1
    "C. Strategi gerilya":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "D. Taktik diplomasi":
        $ hasil["terjawab"] += 1

menu question_6:
    "Apa dampak dari strategi gerilya terhadap pasukan Belanda?"

    "A. Pasukan Belanda mudah menang":
        $ hasil["terjawab"] += 1
    "B. Pasukan Belanda kehilangan arah dan kewalahan":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "C. Pasukan Belanda mundur dari Jawa":
        $ hasil["terjawab"] += 1
    "D. Belanda menyerah tanpa syarat":
        $ hasil["terjawab"] += 1

label scene_4:
    scene bg_rumah_magelang with fade
    show ch_de_kock at left
    "Jenderal De Kock" "Pangeran, kita bertemu untuk membicarakan perdamaian."

    show ch_diponegoro at right
    "Diponegoro" "Saya datang untuk berdamai, bukan untuk dijebak."

    show ch_narator at center with dissolve
    "Narator" "Namun, pertemuan di Magelang hanyalah tipu daya. Diponegoro ditangkap dan diasingkan ke Makassar."

menu question_7:
    "Apa yang terjadi saat perundingan antara Belanda dan Diponegoro di Magelang tahun 1830?"

    "A. Diponegoro diberi jabatan di pemerintahan":
        $ hasil["terjawab"] += 1
    "B. Diponegoro ditangkap dan diasingkan":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "C. Belanda menyerah kepada Diponegoro":
        $ hasil["terjawab"] += 1
    "D. Perang dihentikan secara damai":
        $ hasil["terjawab"] += 1

menu question_8:
    "Siapakah tokoh Belanda yang menjebak Diponegoro?"

    "A. Van den Bosch":
        $ hasil["terjawab"] += 1
    "B. J.P. Coen":
        $ hasil["terjawab"] += 1
    "C. De Kock":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "D. Daendels":
        $ hasil["terjawab"] += 1

label scene_5:
    scene bg_makam_diponegoro with fade
    voice "Scene5_Narator1.mp3"
    "Narator" "Perang Diponegoro berakhir setelah lima tahun. Lebih dari 200 ribu orang tewas, dan Belanda mengeluarkan biaya besar."
    voice "Scene5_RakyatJawa.mp3"
    "Rakyat Jawa" "Kami kehilangan tanah, keluarga, dan pemimpin. Tapi semangat kami tetap hidup."
    voice "Scene5_Narator1.mp3"
    "Sejarawan" "Perang ini adalah simbol perlawanan rakyat Nusantara terhadap kolonialisme. Pangeran Diponegoro dikenang sebagai pahlawan nasional."

menu question_9:
    "Berapa lama Perang Diponegoro berlangsung?"

    "A. 2 tahun":
        $ hasil["terjawab"] += 1
    "B. 5 tahun":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "C. 7 tahun":
        $ hasil["terjawab"] += 1
    "D. 10 tahun":
        $ hasil["terjawab"] += 1

menu question_10:
    "Apa dampak dari Perang Diponegoro bagi Belanda?"

    "A. Tidak ada dampak berarti":
        $ hasil["terjawab"] += 1
    "B. Belanda untung besar":
        $ hasil["terjawab"] += 1
    "C. Biaya perang sangat besar dan menyebabkan reorganisasi":
        $ hasil["terjawab"] += 1
        $ hasil["benar_jawaban"] += 1
    "D. Belanda menguasai seluruh Nusantara":
        $ hasil["terjawab"] += 1

label end:
    $ print(hasil)
    return
