def main():
    question_scene = ""
    question_number = 0
    is_question = True

    with open("question.txt", "r") as qtxt:
        questions_raw = qtxt.read()

    questions = questions_raw.split("\n")
    # print(questions)

    for question in questions:
        if question == "---":
            is_question = True
            question_number += 1
            question_scene += f"menu question_{question_number}:\n"
            continue

        if is_question:
            question_scene += f"    \"{question}\"\n\n"
            is_question = False
        else:
            if question.endswith("*"):
                question_scene += f"    \"{question[:-1]}\":\n        $ data['terjawab'] += 1\n        $ data['benar_jawaban'] += 1\n\n"
            else:
                question_scene += f"    \"{question}\":\n        $ data['terjawab'] += 1\n\n"

    with open("question_scene.txt", "w") as qstxt:
        qstxt.write(question_scene)



if __name__ == "__main__":
    main()